package tps.tp1.pack3Arrays;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

/**
 * Make image Zoom
 * 
 * @author ateofilo
 * 
 */
public class P05BitmapTransform {

	/**
	 * Method that copies the image, apply some pixel transformation.
	 * 
	 * @param image
	 *            the image to be transformed
	 * @return a new image
	 */
	public static BufferedImage copyImage(BufferedImage image) {
		int height = image.getHeight();
		int width = image.getWidth();

		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				int pixelRGB = image.getRGB(x, y);
				int newPixelColor = pixelRGB;

				// TODO testar com uma s� linha activada, entre as seguintes
				newPixelColor = pixelRGB & 0xFF; // s� azul
				// newPixelColor = pixelRGB & 0xFF00; // s� verde
				// newPixelColor = pixelRGB & 0xFF0000; // s� vermelho

				image.setRGB(x, y, newPixelColor);
			}
		}
		return image;
	}

	/**
	 * 
	 * Mirrors the Image
	 * 
	 * @return a new zoom 2x image.
	 */
	public static BufferedImage mirrorImage(BufferedImage image) {
		int height = image.getHeight();
		int width = image.getWidth();

		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width / 2; x++) {
				int pixelRGB = image.getRGB(x, y);

				int newPixelColor = pixelRGB;
				image.setRGB(width - x - 1, y, newPixelColor);
			}
		}

		return image;
	}

	/**
	 * 
	 * TODO Method to be done. It contains some code that have to be changed. You
	 * must use the received image. That is, you should not create a new image.
	 * 
	 * @return a new zoom 2x image.
	 */
	public static BufferedImage zoomImage(BufferedImage image) {
		// TODO Method to be done

		int height = image.getHeight();
		int width = image.getWidth();

		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width / 2; x++) {
				int pixelRGB = image.getRGB(x, y);

				int newPixelColor = pixelRGB;
				image.setRGB(width - x - 1, y, newPixelColor);
			}
		}

		return image;
	}

	/**
	 * show original image
	 * 
	 */
	public static void showOriginalImageTask() throws IOException {
		// read the image to memory
		BufferedImage image = ImageIO.read(P05BitmapTransform.class.getResource("images/image1.jpg"));

		// show original image
		buildFrameForImage(image, "Original image");
	}

	/**
	 * show image with some transformation
	 * 
	 */
	public static void transformTask() throws IOException {
		// read the image to memory
		BufferedImage image = ImageIO.read(P05BitmapTransform.class.getResource("images/image1.jpg"));

		// get a new image that is the transformation of original image
		BufferedImage newImage = copyImage(image);

		// show new image
		buildFrameForImage(newImage, "Copy with just blue");
	}
	
	/**
	 * mirrors image
	 * 
	 */
	public static void mirrorTask() throws IOException {
		// read the image to memory
		BufferedImage image = ImageIO.read(P05BitmapTransform.class.getResource("images/image1.jpg"));

		// apply reduction
		BufferedImage newImage = mirrorImage(image);

		// show reduced image
		buildFrameForImage(newImage, "Mirror image");
	}

	/**
	 * zoom image
	 * 
	 */
	public static void zoomTask() throws IOException {
		// read the image to memory
		BufferedImage image = ImageIO.read(P05BitmapTransform.class.getResource("images/image1.jpg"));

		// apply reduction
		BufferedImage newImage = zoomImage(image);

		// show reduced image
		buildFrameForImage(newImage, "Zoom image");
	}

	/**
	 * Method that shows one image in a new frame
	 */
	public static void buildFrameForImage(BufferedImage image, String title) throws IOException {
		// the frame
		JFrame frame = new JFrame(title);

		// frame should be disposed when we press close button
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		// set frame size
		frame.setSize(400, 300);

		// center the frame
		frame.setLocationRelativeTo(null);

		// show the image inside a label
		ImageIcon img = new ImageIcon(image);
		JLabel label = new JLabel(img, JLabel.CENTER);
		// add the label to frame
		frame.add(label);

		// turn frame visible
		frame.setVisible(true);
	}

	/**
	 * method that gets the blue value from a RGB pixel value
	 */
	static int getRGBBlue(int rgb) {
		return (rgb) & 0xFF;
	}

	/**
	 * method that gets the green value from a RGB pixel value
	 */
	static int getRGBGreen(int rgb) {
		return (rgb >> 8) & 0xFF;
	}

	/**
	 * method that gets the red value from a RGB pixel value
	 */
	static int getRGBRed(int rgb) {
		return (rgb >> 16) & 0xFF;
	}

	/**
	 * method that set the blue value to a RGB pixel value
	 * 
	 * @return the new pixel RGB value
	 */
	static int setRGBBlue(int rgb, int blue) {
		return (rgb & 0xFFFFFF00) | (blue & 0xFF);
	}

	/**
	 * method that sets the green value to a RGB pixel value
	 * 
	 * @return the new pixel RGB value
	 */
	static int setRGBGreen(int rgb, int green) {
		return (rgb & 0xFFFF00FF) | ((green & 0xFF) << 8);
	}

	/**
	 * method that sets the red value to a RGB pixel value
	 * 
	 * @return the new pixel RGB value
	 */
	static int setRGBRed(int rgb, int red) {
		return ((red & 0xFF) << 16) | rgb & 0xFF00FFFF;
	}

	/**
	 * Main method - execution entry point
	 */
	public static void main(String[] args) {

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {

					// show original image
					showOriginalImageTask();

					// show image with some transformation
					transformTask();
					
					// mirrors the image
					mirrorTask();

					// zoom (2x) new image
					zoomTask();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});

	}

}
