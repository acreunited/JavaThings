package tps.tp1.pack2Ciclos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import tps.tp4.layouts.ProportionalLayout;

public class P03ColorFrameCircle extends JFrame {
	private static final long serialVersionUID = -330888082383077655L;

	private static Color INITIAL_OUTSIDE_COLOR = Color.GREEN;
	private static Color INITIAL_INSIDE_COLOR = Color.RED;

	private MyLabel label1;
	private JButton bnColorOutside;
	private JButton bnColorInside;

	protected void init() {
		setTitle("...: ColorFrame :...");
		setSize(400, 300);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		// panel central
		JPanel jpCentral = new JPanel(new ProportionalLayout(0.1f));
		jpCentral.setBackground(Color.ORANGE);
		jpCentral.setOpaque(true);
		add(jpCentral, BorderLayout.CENTER);

		// label central
		label1 = new MyLabel();
		jpCentral.add(label1, ProportionalLayout.CENTER);

		// buttons panel
		JPanel jpButtons = new JPanel();
		add(jpButtons, BorderLayout.SOUTH);

		// button outside color
		bnColorOutside = new JButton("Outside color");
		bnColorOutside.setBackground(INITIAL_OUTSIDE_COLOR);
		bnColorOutside.setOpaque(true);
		bnColorOutside.setHorizontalAlignment(SwingConstants.CENTER);
		jpButtons.add(bnColorOutside);

		// button inside color
		bnColorInside = new JButton("Inside color");
		bnColorInside.setBackground(INITIAL_INSIDE_COLOR);
		bnColorInside.setOpaque(true);
		bnColorInside.setHorizontalAlignment(SwingConstants.CENTER);
		jpButtons.add(bnColorInside);

		// listener start color button
		bnColorOutside.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				Color newColor = JColorChooser.showDialog(P03ColorFrameCircle.this, "Choose Outside Color",
						bnColorOutside.getBackground());
				bnColorOutside.setBackground(newColor);
				label1.repaint();
			}
		});

		// listener end color button
		bnColorInside.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				Color newColor = JColorChooser.showDialog(P03ColorFrameCircle.this, "Choose Inside Color",
						bnColorInside.getBackground());
				bnColorInside.setBackground(newColor);
				label1.repaint();
			}
		});

		// set frame visible
		setVisible(true);
	}

	/**
	 * Main method - the execution starts here
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				P03ColorFrameCircle frame = new P03ColorFrameCircle();
				frame.init();
			}
		});
	}

	/**
	 * Auxiliary class that extends JLabel
	 */
	class MyLabel extends JLabel {
		private static final long serialVersionUID = -4402584053051810107L;

		{
			// setBorder(BorderFactory.createLineBorder(Color.GRAY));
			setBackground(new Color(240, 200, 0));
			setOpaque(true);
		}

		public void paint(Graphics g) {
			super.paint(g);
			System.out.println("Paint...");

			drawColors(g, getWidth(), getHeight(), bnColorOutside.getBackground(), bnColorInside.getBackground());
		}

		/**
		 * Should draw all the drawing area with lines with color varying from
		 * StartColor to EndColor.
		 * 
		 * fillOval(int x, int y, int width, int height), desenha uma oval que ocupa o
		 * rectangulo de x,y at� x+width, y+height. Ter aten��o que n�o � centrado em x,
		 * y.
		 * 
		 * @param g
		 *            the graphics where we should draw the lines
		 * @param dimX
		 *            x dimension of drawing area
		 * @param dimY
		 *            y dimension of drawing area
		 * @param outsideColor
		 *            outside color
		 * @param insideColor
		 *            inside color
		 */
		private void drawColors(Graphics g, int dimX, int dimY, Color outsideColor, Color insideColor) {
			// Color currentColor = outsideColor;

			// TODO .....

			g.setColor(outsideColor);
			g.fillOval(0, 0, dimX, dimY);
			g.setColor(insideColor);
			g.fillOval(dimX / 2 - dimX / 4, dimY / 2 - dimY / 4, dimX / 2, dimY / 2);

		}
	}

}
