package tps.tp2.pack1Recursive;

/**
 * Classe para conter exerc�cios recursivos com inteiro
 */
public class P01WorkWithInts {

	/**
	 * Main, m�todo de arranque da execu��o
	 */
	public static void main(String[] args) {

		// ====================================================
		// test method getLowestIndexWithSameDigit
		test_getLowestIndexWithSameDigit(21, 31); // result = 0
		test_getLowestIndexWithSameDigit(311, 43); // result = -1
		test_getLowestIndexWithSameDigit(311, 413); // result = 1
		test_getLowestIndexWithSameDigit(3121, 31122); // result = 1
		test_getLowestIndexWithSameDigit(-1, 1); // ERRO
		test_getLowestIndexWithSameDigit(1, -1); // ERRO
		test_getLowestIndexWithSameDigit(1, 1); // result = 0
		// pode e deve colocar mais testes aqui
		System.out.println();

		// ====================================================
		// test method test_removeOddDigits
		test_removeOddDigits(14534); // result = 44
		test_removeOddDigits(22345); // result = 224
		test_removeOddDigits(32352); // result = 22
		test_removeOddDigits(533); // result = 0
		test_removeOddDigits(47765); // result = 46
		test_removeOddDigits(0); // result = 0
		test_removeOddDigits(3); // result = 0
		// pode e deve colocar mais testes aqui
		System.out.println();

	}

	/**
	 * Auxiliary method that call getLowestIndexWithSameDigit with the received
	 * arguments and shows the result
	 */
	private static void test_getLowestIndexWithSameDigit(int a, int b) {
		try {

			System.out.print("getLowestIndexWithSameDigit (" + a + ", " + b + ") = ");
			int res = getLowestIndexWithSameDigit(a, b);
			System.out.println(res);

		} catch (IllegalArgumentException e) {
			System.out.println("Erro: " + e.getMessage());
		}
	}

	/**
	 * Este m�todo recebe dois que devem ser inteiros positivos e deve
	 * recursivamente devolver o menor �ndice de d�gito (a come�ar em zero no
	 * d�gito de menor peso), que contenha o mesmo d�gito nos dois n�meros. Deve
	 * devolver -1 caso n�o haja um �ndice com d�gitos iguais nos dois n�meros.
	 * 
	 * @param a
	 *            n�mero de entrada
	 * @param b
	 *            n�mero de entrada
	 * @return o menor �ndice que tem digitos iguais nos dois n� de entrada, ou
	 *         -1 caso n�o haja um �ndice com d�gitos iguais nos dois n�meros
	 */
	private static int getLowestIndexWithSameDigit(int a, int b) {
		if (a < 0 || b < 0)
			throw new IllegalArgumentException("Ambos os argumentos devem ser positivos: " + a + " " + b);

		// TODO ...

		return 0;
	}

	/**
	 * Auxiliary method that call removeOddDigits with the received argument and
	 * shows the result
	 */
	private static void test_removeOddDigits(int a) {
		try {

			System.out.print("removeOddDigits (" + a + ") = ");
			int res = removeOddDigits(a);
			System.out.println(res);

		} catch (IllegalArgumentException e) {
			System.out.println("Erro: " + e.getMessage());
		}
	}

	/**
	 * Este m�todo recebe um inteiro que deve ser positivo e deve recursivamente
	 * devolver o mesmo n�mero mas sem os seus d�gitos �mpares.
	 * 
	 * @param a
	 *            n�mero de entrada
	 * @return o n� de entrada, mas sem os seus d�gitos �mpares
	 */
	private static int removeOddDigits(int a) {
		if (a < 0)
			throw new IllegalArgumentException("O argumento deve ser positivo: " + a);

		// TODO ...

		return 0;
	}
}
