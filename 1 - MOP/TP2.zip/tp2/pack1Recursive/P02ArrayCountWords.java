package tps.tp2.pack1Recursive;

public class P02ArrayCountWords {

	/**
	 * Main
	 */
	public static void main(String[] args) {

		// ===============================================
		// test method trimLeadingSpaces
		test_trimLeadingSpaces("abc"); // = [abc]
		test_trimLeadingSpaces("   abc  "); // = [abc ]
		test_trimLeadingSpaces("   "); // = []
		test_trimLeadingSpaces(""); // = []
		test_trimLeadingSpaces(null); /// = Erro: The received array is null
		System.out.println();

		// ===============================================
		// test method endOfLeadingWord
		test_idxFirstSpace("abc"); // = 3
		test_idxFirstSpace("abc  "); // = 3
		test_idxFirstSpace("abc  def"); // = 3
		test_idxFirstSpace("    "); // = 0
		test_idxFirstSpace(""); // = 0
		test_idxFirstSpace(null); // = Erro: The received array is null
		System.out.println();

		// ===============================================
		// test method coundWords
		test_coundWords("abc"); // = 1
		test_coundWords("  abc  "); // = 1
		test_coundWords(" abc  def"); // = 2
		test_coundWords(" abc def d"); // = 3
		test_coundWords("a a  def  d   g "); // = 5
		test_coundWords("   "); // = 0
		test_coundWords(""); // = 0
		test_coundWords(null); // = Erro: The received array is null
	}

	/**
	 * Auxiliary method that call trimLeadingSpaces with the received array and
	 * shows the result
	 */
	public static void test_trimLeadingSpaces(String array) {
		try {

			System.out.print("trimLeadingSpaces (" + array + ") = ");
			char[] res = trimLeadingSpaces(array == null ? null : array.toCharArray());
			System.out.println("[" + new String(res) + "]");

		} catch (IllegalArgumentException e) {
			System.out.println("Erro: " + e.getMessage());
		}
	}

	/**
	 * Este m�todo recebe um array de char deve eliminar os espa�os no seu
	 * in�cio mas de forma recursiva. Este m�todo deve fazer c�pias de arrays
	 * com Arrays.copyOfRange
	 * 
	 * @param array
	 *            o array a processar
	 * @return o array recebido mas sem espa�os no in�cio. Pode resultar num
	 *         array vazio
	 */
	public static char[] trimLeadingSpaces(char[] array) {
		if (array == null)
			throw new IllegalArgumentException("The received array is null");

		// TODO: devem editar este m�todo
		return null; // eliminar esta instru��o, est� aqui s� para evitar dar um
						// erro
	}

	/**
	 * Auxiliary method that call idxFirstSpace with the received array and
	 * shows the result
	 */
	public static void test_idxFirstSpace(String array) {
		try {

			System.out.print("idxFirstSpace (" + array + ") = ");
			int res = idxFirstSpace(array == null ? null : array.toCharArray(), 0);
			System.out.println(res);

		} catch (IllegalArgumentException e) {
			System.out.println("Erro: " + e.getMessage());
		}
	}

	/**
	 * Este m�todo recebe um array de chars e deve determinar de forma recursiva
	 * e devolver o �ndice do primeiro espa�o encontrado ou array.lenght caso
	 * n�o encontre nenhum espa�o. Este m�todo n�o dever� fazer c�pias do array,
	 * mas sim utilizar o �ndice do argumento.
	 * 
	 * Validar se o indice recebido � v�lido (dentro do array), caso contr�rio
	 * lan�ar uma excep��o de IllegalArgumentException
	 */
	/**
	 * 
	 * @param array
	 *            o array a processar
	 * @param currentIdx
	 *            o �ndice do elemento corrente a analisar
	 * @return
	 */
	public static int idxFirstSpace(char[] array, int currentIdx) {
		if (array == null)
			throw new IllegalArgumentException("The received array is null");

		// TODO: devem editar este m�todo
		return 0; // eliminar esta instru��o, est� aqui s� para evitar dar um
					// erro
	}

	/**
	 * Auxiliary method that call coundWords with the received array and shows
	 * the result
	 */
	public static void test_coundWords(String array) {
		try {

			System.out.print("coundWords (" + array + ") = ");
			int res = countWords(array == null ? null : array.toCharArray());
			System.out.println(res);

		} catch (IllegalArgumentException e) {
			System.out.println("Erro: " + e.getMessage());
		}
	}

	/**
	 * Este m�todo recebe um array de chars e deve determinar de forma recursiva
	 * e devolver o n�mero de palavras (words) existentes dentro do array.
	 * Considera-se como separador somente o caracter espa�o. Este m�todo dever�
	 * utilizar os outros dois m�todos e dever� fazer c�pias de arrays com
	 * Arrays.copyOfRange
	 * 
	 * @param array
	 *            o array a processar
	 * @return o n�mero de palavras existentes no array recebido
	 */
	public static int countWords(char[] array) {
		if (array == null)
			throw new IllegalArgumentException("The received array is null");

		// TODO: devem editar este m�todo

		// limpar espa�os iniciais

		// obter �ndice do final da primeira palavra

		// chamada recursiva para contar as palavras desde o fim da primeira
		// palavra at� ao final do array

		return 0; // eliminar esta instru��o, est� aqui s� para evitar dar um
					// erro
	}

}
