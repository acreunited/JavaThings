package bookcode.p08Inheritance;

/**
 * Class of fruit
 */
public class C16Fruit {
	
	private String fruitName;

	public C16Fruit() {
		fruitName = "";
	}

	public C16Fruit(String name) {
		fruitName = name;
	}

	public void setName(String name) {
		fruitName = name;
	}

	public String getName() {
		return fruitName;
	}
}
