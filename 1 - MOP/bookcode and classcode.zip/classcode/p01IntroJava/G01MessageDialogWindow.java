package classcode.p01IntroJava;

import javax.swing.*;

/**
 * Message dialog window
 */
public class G01MessageDialogWindow {

	/**
	 * main method
	 */
	public static void main(String[] args) {

		// message dialog with information message type and no title
		JOptionPane.showMessageDialog(null, "Hello World!");
	}
}
