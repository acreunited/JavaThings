package classcode.p01IntroJava;

public class C13BoxingUnboxing {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// auto boxing - automatic conversion from int to integer
		Integer i1 = 20;
		Integer i2 = Integer.valueOf(20);

		System.out.println("Integer i1 = 20;    i1 -> " + i1 + " " + i1.getClass());
		System.out.println("Integer i2 = Integer.valueOf(20);    i2 -> " + i2 + " " + i2.getClass());

		// auto unboxing - automatic conversion from Integer to int
		int i3 = i1;
		System.out.println("\nint i3 = i1;    i3 -> " + i3);
		
		int i4 = i1.intValue();
		System.out.println("int i4 = i1.intValue();    i4 -> " + i4);

	}

}
