package classcode.p01IntroJava;

public class C01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
