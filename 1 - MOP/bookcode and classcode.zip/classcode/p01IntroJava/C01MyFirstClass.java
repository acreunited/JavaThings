package classcode.p01IntroJava;

/**
 * Primeira classe de MoP
 * 
 * @author ateofilo
 *
 */
public class C01MyFirstClass extends Object {

	/**
	 * Main method - este � o m�todo de arranque deste ficheiro
	 */
	public static void main(String[] args) { /* jjj */

		// TODO fazer mais tarde
		System.out.println("Ol� pessoal");
		System.out.println("Ol� pessoal");
		System.out.println("www");
		System.out.println(); // jhgjhg gjhgjhg gh

		int i = 10;
		i = i * 200;
		System.out.println(i);
		// byte b = (byte) i; // ERRO WARNING
		m1();

	}

	static void m1() {
		System.out.println("ola");
	}
}
