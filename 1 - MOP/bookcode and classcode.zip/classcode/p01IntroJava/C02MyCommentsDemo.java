package classcode.p01IntroJava;

public class C02MyCommentsDemo {

	/**
	 * Main method - this is a block doc comment
	 */
	public static void main(String[] args) {
		// line comment TODO do something

		/*
		 * block comment HERE put comment
		 */
		System.out.println("Just comments... I'm bored!!!!"   );
	}
}
