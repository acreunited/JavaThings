package classcode.p03IntroMethods;

import java.util.Scanner;

public class C05PrintSquareV2 {

	/**
	 * main method
	 */
	public static void main(String[] args) {
		// the keyboard reader
		Scanner keyboard = new Scanner(System.in);

		// read length of square side
		System.out.println("Entering the length of square side:");
		int squareSide = C02LowestCommonMultipleV2.readPositiveNonZeroInteger(keyboard);

		// draw the square
		printSquare(squareSide, '#');
		System.out.println();

		// draw a square with size 3
		printSquare(3, '$');
	}

	/**
	 * Prints a square with the received size and received char
	 * 
	 * @param dimSquare
	 *            the size of the square
	 * @param printChar
	 *            the char to print the square
	 */
	public static void printSquare(int dimSquare, char printChar) {
		
		// run over the lines
		for (int nLinha = 0; nLinha < dimSquare; nLinha++) {
			
			// run over the columns
			for (int nColuna = 0; nColuna < dimSquare; nColuna++) {
				// print one char
				System.out.print(printChar);
			}
			
			// change line at the end of each line
			System.out.println();
		}
	}
}
