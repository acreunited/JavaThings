package classcode.p08AbstractClassesAndInterfaces;

public interface C06IWritable {

	String toString();

	void writeOutput(String prefix);
}
