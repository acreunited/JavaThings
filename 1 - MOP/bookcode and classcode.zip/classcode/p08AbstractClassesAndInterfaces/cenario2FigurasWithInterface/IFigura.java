package classcode.p08AbstractClassesAndInterfaces.cenario2FigurasWithInterface;

import java.awt.Graphics;

public interface IFigura {

	/**
	 * 
	 */
	C02Ponto2D[] getPontos();

	/**
	 * 
	 */
	void setPontos(C02Ponto2D[] pontos);

	/**
	 * 
	 */
	C02Ponto2D getPonto(int index);

	/**
	 * 
	 */
	boolean setPonto(C02Ponto2D ponto, int index);

	/**
	 * 
	 */
	double getArea();

	/**
	 * 
	 */
	String getNome();

	/**
	 * 
	 */
	String toString();

	/**
	 * 
	 */
	void paintComponent(Graphics g);

}