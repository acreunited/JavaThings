package classcode.p08AbstractClassesAndInterfaces.cenario2FigurasWithInterface;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Polygon;
import java.util.Arrays;

/**
 * Classe Figura - Esta classe � um contentor de pontos.
 * 
 * Os m�todos getArea e getNome s�o agora abstract
 * 
 */
public abstract class C04Figura implements IFigura {
	C02Ponto2D[] pontos;
	private int nPontos;
	Color color;

	/**
	 * 
	 */
	public C04Figura(Color color) {
		pontos = null;
		nPontos = 0;
		this.color = color;
	}

	/**
	 * 
	 */
	public C04Figura(C02Ponto2D[] pontos, Color color) {
		setPontos(pontos);
		this.color = color;
	}

	/* (non-Javadoc)
	 * @see classcode.p08AbstractClassesAndInterfaces.cenario2FigurasWithInterface.IFIgura#getPontos()
	 */
	@Override
	public C02Ponto2D[] getPontos() {
		// TODO
		return new C02Ponto2D[0];
	}

	/* (non-Javadoc)
	 * @see classcode.p08AbstractClassesAndInterfaces.cenario2FigurasWithInterface.IFIgura#setPontos(classcode.p08AbstractClassesAndInterfaces.cenario2FigurasWithInterface.C02Ponto2D[])
	 */
	@Override
	public void setPontos(C02Ponto2D[] pontos) {
		this.pontos = Arrays.copyOf(pontos, pontos.length);
		nPontos = pontos.length;
		// TODO copiar os pontos em si
	}

	/* (non-Javadoc)
	 * @see classcode.p08AbstractClassesAndInterfaces.cenario2FigurasWithInterface.IFIgura#getPonto(int)
	 */
	@Override
	public C02Ponto2D getPonto(int index) {
		if (index < 0 || index >= pontos.length)
			return null;
		return pontos[index].clone();
	}

	/* (non-Javadoc)
	 * @see classcode.p08AbstractClassesAndInterfaces.cenario2FigurasWithInterface.IFIgura#setPonto(classcode.p08AbstractClassesAndInterfaces.cenario2FigurasWithInterface.C02Ponto2D, int)
	 */
	@Override
	public boolean setPonto(C02Ponto2D ponto, int index) {
		if (index < 0 || index >= pontos.length)
			return false;

		pontos[index] = ponto.clone();
		return true;
	}

	/* (non-Javadoc)
	 * @see classcode.p08AbstractClassesAndInterfaces.cenario2FigurasWithInterface.IFIgura#getArea()
	 */
	@Override
	public abstract double getArea() ;

	/* (non-Javadoc)
	 * @see classcode.p08AbstractClassesAndInterfaces.cenario2FigurasWithInterface.IFIgura#getNome()
	 */
	@Override
	public abstract String getNome();

	/* (non-Javadoc)
	 * @see classcode.p08AbstractClassesAndInterfaces.cenario2FigurasWithInterface.IFIgura#toString()
	 */
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder(getNome());
		s.append(" [");
		for (int i = 0; i < nPontos; i++) {
			s.append(pontos[i]);
			if (i < nPontos - 1)
				s.append(", ");
		}
		s.append("]");
		return s.toString();

	}

	/* (non-Javadoc)
	 * @see classcode.p08AbstractClassesAndInterfaces.cenario2FigurasWithInterface.IFIgura#paintComponent(java.awt.Graphics)
	 */
	@Override
	public void paintComponent(Graphics g) {

		Polygon p = new Polygon();
		for (int i = 0; i < pontos.length; i++) {
			p.addPoint(pontos[i].getX(), pontos[i].getY());
		}

		g.setColor(color);
		g.fillPolygon(p);
		g.setColor(Color.black);
		g.drawPolygon(p);

	}
}
