package classcode.p13EDD;

import java.io.Serializable;

public class C09Serializable implements Serializable {

	// private static final long serialVersionUID = 1L;

	private static final long serialVersionUID = 7707200347726565875L;
	// s� para mostrar que se deve declarar o serialversionUID
	// como em MoP n�o vamos utilizar a serializa��o este atributo pode ter um
	// valor qualquer, inclusive 1 ou mesmo 0
}
